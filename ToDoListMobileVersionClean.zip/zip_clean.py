import zipfile
import os

exclude = ['.buildozer', 'buildenv', 'external', 'bin']
folder_to_zip = r'D:\MainMob\To-DoListMobileVersion'
output_zip = r'D:\MainMob\ToDoListMobileVersionClean.zip'

with zipfile.ZipFile(output_zip, 'w', zipfile.ZIP_DEFLATED) as zipf:
    for root, dirs, files in os.walk(folder_to_zip):
        if any(ex in root for ex in exclude):
            continue
        for file in files:
            filepath = os.path.join(root, file)
            arcname = os.path.relpath(filepath, folder_to_zip)
            zipf.write(filepath, arcname)

print("ZIP complete 🎉")